classdef coaxial_test
    %coaxial_test A class to containg data and related functions to take
    %care of a single coaxial rotor map experiment.
    %   Detailed explanation goes here
    
    properties
        DataTable
        OptDataTable
        PropSeparationRatio = 0;
        RotorDiameter = 0;
        RotorRadius = 0;
        RotorArea = 0;
        Name = 'none';
        OptName = 'none';
        %air density
        rho = 1.225;
        %kinematic viscosity of air
        mi = 1.4207e-5;
        Type
        
        upper_i_m
        upper_i
        equal_cmd_i

        BezierCoeffUpper
        UpperCommandSplineFit
        UpperCommandSplineFit15

        BezierCoeffLower
        LowerCommandSplineFit
        LowerCommandSplineFit15
        
        nColors = {'black','red','#EDB120','blue','magenta','green'};
    end
    
    methods
        function obj = build(obj,data_path, file, name,zD,D)
            
            %Build Construct an instance of this class
            %Fill the class with its basic data
            path = [data_path,file];
            file_opts = detectImportOptions(path);
            file_opts.PreserveVariableNames = true;
            obj.DataTable = readtable(path,file_opts);
            obj.Name = name;
            obj.PropSeparationRatio = zD;
            obj.RotorDiameter = D;

            obj.RotorRadius = D/2;
            %disk area
            obj.RotorArea = pi*obj.RotorRadius*obj.RotorRadius;
          
            %Calculate general quantities of interest
            obj.DataTable = obj.calc_quantities_of_interest(obj.DataTable);
            
            if contains(file, 'single')
            %do nothing 
            else
            obj = obj.get_upper_boundary_test_map(obj.DataTable);
            end
            
        end
        
        function NewDataTable = calc_quantities_of_interest(obj,DataTable)
            %calc_quantities_of_interest: It gets the raw data table and calculate the
            %quantities of more interest
            
            NewDataTable = DataTable;
            sz = size(NewDataTable);
            NewDataTable = NewDataTable(3:sz(1)-1,:);
          
            %Calculate and add new collums for the variables of interest
            %calculate electrical power
            NewDataTable.("Upper ePower [W]") = NewDataTable.("Voltage Left [V]").*NewDataTable.("Current Left [A]");
            NewDataTable.("Lower ePower [W]") = NewDataTable.("Voltage Right [V]").*NewDataTable.("Current Right [A]");
            NewDataTable.("Total ePower [W]") = NewDataTable.("Upper ePower [W]") + NewDataTable.("Lower ePower [W]");

            %calculate electrical efficiency
            NewDataTable.("Upper eEfficiency [g/W]") = NewDataTable.("Thrust Left [g]")./NewDataTable.("Upper ePower [W]");
            NewDataTable.("Lower eEfficiency [g/W]") = NewDataTable.("Thrust Right [g]")./NewDataTable.("Lower ePower [W]");
            NewDataTable.("Total eEfficiency [g/W]") = NewDataTable.("Total Thrust [g]")./NewDataTable.("Total ePower [W]");

            %calculate electrical efficiency
            NewDataTable.("Upper etEfficiency [Nm/W]") = abs(NewDataTable.("Torque Left [Nm]"))./NewDataTable.("Upper ePower [W]");
            NewDataTable.("Lower etEfficiency [Nm/W]") = abs(NewDataTable.("Torque Right [Nm]"))./NewDataTable.("Lower ePower [W]");

            %Convert PWM to Command %
            NewDataTable.("Upper Command [%]") = (NewDataTable.("PWM Left")-1000)/10;
            NewDataTable.("Lower Command [%]") = (NewDataTable.("PWM Right")-1000)/10;
            
            NewDataTable.("Upper Speed [rad/s]") = NewDataTable.("Speed Left [rpm]")*(2*pi/60);
            NewDataTable.("Lower Speed [rad/s]") = NewDataTable.("Speed Right [rpm]")*(2*pi/60);

            %calculate mechanical power
            NewDataTable.("Upper mPower [W]") = -NewDataTable.("Torque Left [Nm]").*NewDataTable.("Upper Speed [rad/s]");
            NewDataTable.("Lower mPower [W]") = NewDataTable.("Torque Right [Nm]").*NewDataTable.("Lower Speed [rad/s]");
            NewDataTable.("Total mPower [W]") = NewDataTable.("Upper mPower [W]") + NewDataTable.("Lower mPower [W]");

            %calculate mechanical efficiency
            NewDataTable.("Upper mEfficiency [g/W]") = NewDataTable.("Thrust Left [g]")./NewDataTable.("Upper mPower [W]");
            NewDataTable.("Lower mEfficiency [g/W]") = NewDataTable.("Thrust Right [g]")./NewDataTable.("Lower mPower [W]");
            NewDataTable.("Total mEfficiency [g/W]") = NewDataTable.("Total Thrust [g]")./NewDataTable.("Total mPower [W]");
            
            %calculate thrust coefficient
            NewDataTable.("Upper C_T") = (9.81/1000)*NewDataTable.("Thrust Left [g]")./( 0.5*obj.rho*obj.RotorArea*(obj.RotorRadius*obj.RotorRadius).*(NewDataTable.("Upper Speed [rad/s]").*NewDataTable.("Upper Speed [rad/s]")) );
            NewDataTable.("Lower C_T") = (9.81/1000)*NewDataTable.("Thrust Right [g]")./( 0.5*obj.rho*obj.RotorArea*(obj.RotorRadius*obj.RotorRadius).*(NewDataTable.("Lower Speed [rad/s]").*NewDataTable.("Lower Speed [rad/s]")) );
            
            %calculate power coefficient
            NewDataTable.("Upper C_P") = NewDataTable.("Upper mPower [W]")./( 0.5*obj.rho*obj.RotorArea*(obj.RotorRadius*obj.RotorRadius*obj.RotorRadius).*(NewDataTable.("Upper Speed [rad/s]").*NewDataTable.("Upper Speed [rad/s]").*NewDataTable.("Upper Speed [rad/s]")) );
            NewDataTable.("Lower C_P") = NewDataTable.("Lower mPower [W]")./( 0.5*obj.rho*obj.RotorArea*(obj.RotorRadius*obj.RotorRadius*obj.RotorRadius).*(NewDataTable.("Lower Speed [rad/s]").*NewDataTable.("Lower Speed [rad/s]").*NewDataTable.("Lower Speed [rad/s]")) );
            
            %torque coefficient
            NewDataTable.("Upper C_Q") = NewDataTable.("Upper C_P");
            NewDataTable.("Lower C_Q") = NewDataTable.("Lower C_P");
            
            NewDataTable.("Lower C_T/Upper C_T") = NewDataTable.("Lower C_T")./NewDataTable.("Upper C_T");
            
            %Calculate figure of merit Eq 3 of Manikandan Ramasamy 2013 paper 
            NewDataTable.("Figure of Merit (Mechanical)") = ( ( (NewDataTable.("Thrust Left [g]")*(9.81/1000)).^(3/2) + (NewDataTable.("Thrust Right [g]")*(9.81/1000)).^(3/2) )/( sqrt(2*obj.rho*obj.RotorArea) ) ) ./ (NewDataTable.("Upper mPower [W]") + NewDataTable.("Lower mPower [W]"));
            NewDataTable.("Figure of Merit (Electrical)") = ( ( (NewDataTable.("Thrust Left [g]")*(9.81/1000)).^(3/2) + (NewDataTable.("Thrust Right [g]")*(9.81/1000)).^(3/2) )/( sqrt(2*obj.rho*obj.RotorArea) ) ) ./ (NewDataTable.("Upper ePower [W]") + NewDataTable.("Lower ePower [W]"));
        
            %Calculate figure of merit Eq 3 of Manikandan Ramasamy 2013 paper 
            NewDataTable.("Figure of Merit abs (Mechanical)") = ( ( (abs(NewDataTable.("Thrust Left [g]"))*(9.81/1000)).^(3/2) + (abs(NewDataTable.("Thrust Right [g]"))*(9.81/1000)).^(3/2) )/( sqrt(2*obj.rho*obj.RotorArea) ) ) ./ (NewDataTable.("Upper mPower [W]") + NewDataTable.("Lower mPower [W]"));
            NewDataTable.("Figure of Merit abs (Electrical)") = ( ( (abs(NewDataTable.("Thrust Left [g]"))*(9.81/1000)).^(3/2) + (abs(NewDataTable.("Thrust Right [g]"))*(9.81/1000)).^(3/2) )/( sqrt(2*obj.rho*obj.RotorArea) ) ) ./ (NewDataTable.("Upper ePower [W]") + NewDataTable.("Lower ePower [W]"));
            
            %Calculate figure of merit Eq 3 of Manikandan Ramasamy 2013 paper 
            NewDataTable.("Figure of Merit sign (Mechanical)") = ( ( sign(NewDataTable.("Thrust Left [g]")).*(abs(NewDataTable.("Thrust Left [g]"))*(9.81/1000)).^(3/2) + sign(NewDataTable.("Thrust Right [g]")).*(abs(NewDataTable.("Thrust Right [g]"))*(9.81/1000)).^(3/2) )/( sqrt(2*obj.rho*obj.RotorArea) ) ) ./ (NewDataTable.("Upper mPower [W]") + NewDataTable.("Lower mPower [W]"));
            NewDataTable.("Figure of Merit sign (Electrical)") = ( ( sign(NewDataTable.("Thrust Left [g]")).*(abs(NewDataTable.("Thrust Left [g]"))*(9.81/1000)).^(3/2) + sign(NewDataTable.("Thrust Right [g]")).*(abs(NewDataTable.("Thrust Right [g]"))*(9.81/1000)).^(3/2) )/( sqrt(2*obj.rho*obj.RotorArea) ) ) ./ (NewDataTable.("Upper ePower [W]") + NewDataTable.("Lower ePower [W]"));
            
            %Calculate figure of merit Eq 3 of Manikandan Ramasamy 2013 paper 
            NewDataTable.("Figure of Merit old (Mechanical)") = ( ( ((NewDataTable.("Thrust Left [g]") + NewDataTable.("Thrust Right [g]"))*(9.81/1000)).^(3/2) )/( sqrt(2*obj.rho*obj.RotorArea) ) ) ./ (NewDataTable.("Upper mPower [W]") + NewDataTable.("Lower mPower [W]"));
            NewDataTable.("Figure of Merit old (Electrical)") = ( ( ((NewDataTable.("Thrust Left [g]") + NewDataTable.("Thrust Right [g]"))*(9.81/1000)).^(3/2) )/( sqrt(2*obj.rho*obj.RotorArea) ) ) ./ (NewDataTable.("Upper ePower [W]") + NewDataTable.("Lower ePower [W]"));
        
        end
        
        function OptDataTable = calc_quantities_of_interest_opt(obj, data_path, file, name)
            %calc_quantities_of_interest_opt: It gets the raw data table and calculate the
            %quantities of more interest for tests reproducing maximum efficiency.
            
            %create a new table iqual to the input, but clear from idle points, and
            %with current offset
            
            path = [data_path,file];
            file_opts = detectImportOptions(path);
            file_opts.PreserveVariableNames = true;
            obj.OptDataTable = readtable(path,file_opts);
            obj.OptName = name;
            
            %Calculate general quantities of interest
            OptDataTable = obj.calc_quantities_of_interest(obj.OptDataTable);
        end
        
        
        function plot_quant_vs_quant(obj, DataTable, x_name, y_name)
            %plots basic quantities
%             figure('Position', [10 10 300 250]);
            plot(DataTable.(x_name), DataTable.(y_name),'*')
            ylabel(y_name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            xlabel(x_name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            title(obj.Name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            colororder(obj.nColors)
        end
        
        function plot3_quant_vs_quant(obj, DataTable, x_name, y_name, z_name)
            %plots basic quantities
            figure('Position', [10 10 300 250]);
            plot3(DataTable.(x_name), DataTable.(y_name), DataTable.(z_name),'*')
            zlabel(z_name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            ylabel(y_name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            xlabel(x_name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            title(obj.Name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            colororder(obj.nColors)
        end
        
        function obj = get_upper_boundary_test_map(obj, DataTable)
            [obj.upper_i_m] = get_upper_boundary(DataTable.("Total Thrust [g]"),DataTable.("Total mEfficiency [g/W]"),15);
            [obj.upper_i] = get_upper_boundary(DataTable.("Total Thrust [g]"),DataTable.("Total eEfficiency [g/W]"),15);
            obj.equal_cmd_i = find(DataTable.("PWM Left") == DataTable.("PWM Right"));
        end

        function obj = bezier_fit(obj, DataTable)
            %Fit each command separately on a Bezier spline fashion (https://www.desmos.com/calculator/cahqdxeshd)
            %Here we fit for the electric ceiling
            %====== Fit PWM Upper =========%
            T = DataTable.("Total Thrust [g]")(obj.upper_i);
            x = [0; T*(1/(max(T)))];
            y = [0;(DataTable.("Upper Command [%]")(obj.upper_i))*(1/(100))];
            upper = y;
            opts = statset('nlinfit');
            opts.RobustWgtFun = 'bisquare';
            b0 = [0.08 0.242];
            modelstr = 'y ~ (1-x)*((1-x)*(x*b1)+x*((1-x)*b1+x*b2))+x*((1-x)*((1-x)*b1+x*b2)+x*((1-x)*b2+x))';
            
            mdl = fitnlm(x,y,modelstr,b0,'Options',opts);
            b = mdl.Coefficients.Estimate;
%             map_table_preocessed.("Spline Points")(1:2) = b;
            obj.BezierCoeffUpper = b;
            %formula
            s = linspace(0,1,100);
            fml = @(x,t)( (1-t).*((1-t).*(t.*x(1))+t.*((1-t).*x(1)+t.*x(2)))+t.*((1-t).*((1-t).*x(1)+t.*x(2))+t.*((1-t).*x(2)+t)) );
            upper_fit = fml(b,s);
%             map_table_preocessed.("Upper Command Spline Fit")(1:100) = upper_fit;
            obj.UpperCommandSplineFit = upper_fit;
            %====== Fit PWM Upper END =========%
            
            %output values for static test
            s15 = linspace(0,1,15);
            obj.UpperCommandSplineFit15 = fml(b,s15);
            
            %====== Fit PWM lower =========%
            y = [0;(DataTable.("Lower Command [%]")(obj.upper_i))*(1/(100))];
            lower = y;
            opts = statset('nlinfit');
            opts.RobustWgtFun = 'bisquare';
            b0 = [0.08 0.242];
            modelstr = 'y ~ (1-x)*((1-x)*(x*b1)+x*((1-x)*b1+x*b2))+x*((1-x)*((1-x)*b1+x*b2)+x*((1-x)*b2+x))';
            
            mdl = fitnlm(x,y,modelstr,b0,'Options',opts);
            b = mdl.Coefficients.Estimate;
%             map_table_preocessed.("Spline Points")(3:4) = b;
            obj.BezierCoeffLower = b;
            %formula
            s = linspace(0,1,100);
            fml = @(x,t)( (1-t).*((1-t).*(t.*x(1))+t.*((1-t).*x(1)+t.*x(2)))+t.*((1-t).*((1-t).*x(1)+t.*x(2))+t.*((1-t).*x(2)+t)) );
            lower_fit = fml(b,s);
%             map_table_preocessed.("Lower Command Spline Fit")(1:100) = fml(b,s);
            obj.LowerCommandSplineFit = fml(b,s);
            %====== Fit PWM lower END =========%
            
%             map_table_preocessed.("Lower Command Spline Fit 15")(1:15) = fml(b,s15);
            obj.LowerCommandSplineFit15 = fml(b,s15);
        end
        
        function plot_quant_vs_quant_boundary(obj, DataTable, x_name, y_name)
            %plots basic quantities
%             figure('Position', [10 10 300 250]);
            plot(DataTable.(x_name)(obj.upper_i), DataTable.(y_name)(obj.upper_i),'-*')
            ylabel(y_name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            xlabel(x_name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            title(obj.Name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            colororder(obj.nColors)
        end

%         function plot_bezier_boundary(obj, DataTable)
%             plot(DataTable.('Total Thrust [g]')(obj.upper_i), obj.UpperCommandSplineFit15*100,'-*')
%             ylabel('Bezier Command Fit [%]','FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
%             xlabel('Total Thrust [g]','FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
%             title(obj.Name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
%             colororder(obj.nColors)
%         end
        
        function plot_quant_vs_quant_plus_at_boundary(obj, DataTable, x_name, y_name)
            %plots basic quantities
            figure('Position', [10 10 300 250]);
            plot(DataTable.(x_name), DataTable.(y_name),'*')
            hold on
            plot(DataTable.(x_name)(obj.upper_i), DataTable.(y_name)(obj.upper_i),'-*')
            ylabel(y_name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            xlabel(x_name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            title(obj.Name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            legend('All','Boundary','Location','southoutside','Orientation','vertical','FontSize',12,'FontWeight','normal','FontName','Times','Interpreter','tex');
            colororder(obj.nColors)
        end
        
        function plot_quant_vs_quant_plus_at_boundary_plus_equal_cmd(obj, DataTable, x_name, y_name)
            %plots basic quantities
%             figure('Position', [10 10 300 250]);
            plot(DataTable.(x_name), DataTable.(y_name),'*')
            hold on
            plot(DataTable.(x_name)(obj.upper_i), DataTable.(y_name)(obj.upper_i),'-*')
            plot(DataTable.(x_name)(obj.equal_cmd_i), DataTable.(y_name)(obj.equal_cmd_i),'-*')
            ylabel(y_name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            xlabel(x_name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            title(obj.Name,'FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
            legend('All','Boundary','Equal Commands','Location','southoutside','Orientation','vertical','FontSize',12,'FontWeight','normal','FontName','Times','Interpreter','tex');
            colororder(obj.nColors)
        end

    end
end

