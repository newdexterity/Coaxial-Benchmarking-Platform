clear all

%relevant quantities
%propeller diameter
D16 = 0.406; %16 in

data_path = 'C:\Users\joaos\OneDrive\Documents\[PhD]\Project Omnidirectional Vehicle\Vanes\CASE Workshop 2022\Materials\Data\';

%declare the coaxial set
p16in_prop_400kv = coaxial_set;

%include the tests
p16in_prop_400kv.zD_025 = p16in_prop_400kv.zD_025.build(data_path, 'data2022_06_13_16_23_27_16in_prop_400kv_22V_MN4014_T_motor_map10x10_full_range_zD_025.csv', '16 in, z/D = 0.25', 0.25, D16);

%%
%Plot the map for the whole actuation domain
p16in_prop_400kv.zD_025.plot3_quant_vs_quant(p16in_prop_400kv.zD_025.DataTable,'PWM Left', 'PWM Right','Thrust Right [g]');
p16in_prop_400kv.zD_025.plot3_quant_vs_quant(p16in_prop_400kv.zD_025.DataTable,'PWM Left', 'PWM Right','Thrust Left [g]');
p16in_prop_400kv.zD_025.plot3_quant_vs_quant(p16in_prop_400kv.zD_025.DataTable,'PWM Left', 'PWM Right','Total Thrust [g]');

%%
%Identify the efficiency ceiling
figure
p16in_prop_400kv.zD_025.plot_quant_vs_quant(p16in_prop_400kv.zD_025.DataTable,'Total Thrust [g]', 'Total eEfficiency [g/W]');
hold on 
p16in_prop_400kv.zD_025.plot_quant_vs_quant_boundary(p16in_prop_400kv.zD_025.DataTable,'Total Thrust [g]', 'Total eEfficiency [g/W]');

%%
%Observe it is above the equal commands control policy
figure
p16in_prop_400kv.zD_025.plot_quant_vs_quant_plus_at_boundary_plus_equal_cmd(p16in_prop_400kv.zD_025.DataTable,'Total Thrust [g]', 'Total eEfficiency [g/W]');

%%
%Identify the commands that result in the efficiency ceiling
figure
p16in_prop_400kv.zD_025.plot_quant_vs_quant_boundary(p16in_prop_400kv.zD_025.DataTable,'Upper Command [%]', 'Lower Command [%]');

figure
p16in_prop_400kv.zD_025.plot_quant_vs_quant_boundary(p16in_prop_400kv.zD_025.DataTable,'Total Thrust [g]','Upper Command [%]');
hold on
p16in_prop_400kv.zD_025.plot_quant_vs_quant_boundary(p16in_prop_400kv.zD_025.DataTable,'Total Thrust [g]','Lower Command [%]');
ylabel('Commands [%]','FontSize',12,'FontWeight','normal','FontName','Times','Color','k');
legend('Upper','Lower','Location','southoutside','Orientation','vertical','FontSize',12,'FontWeight','normal','FontName','Times','Interpreter','tex');

%%
%Do the Bezier fitting for the maximum efficiency
p16in_prop_400kv.zD_025 = p16in_prop_400kv.zD_025.bezier_fit(p16in_prop_400kv.zD_025.DataTable);

% p16in_prop_400kv.zD_025.plot_bezier_boundary(p16in_prop_400kv.zD_025.DataTable);

%Check the Bezier fitting
figure
plot(p16in_prop_400kv.zD_025.UpperCommandSplineFit15*100,p16in_prop_400kv.zD_025.LowerCommandSplineFit15*100)
hold on
p16in_prop_400kv.zD_025.plot_quant_vs_quant_boundary(p16in_prop_400kv.zD_025.DataTable,'Upper Command [%]', 'Lower Command [%]');
legend('Bezier Fit','Experiments','Location','southoutside','Orientation','vertical','FontSize',12,'FontWeight','normal','FontName','Times','Interpreter','tex');


%%
%Get the optimal tests
p16in_prop_400kv.zD_025.OptDataTable = p16in_prop_400kv.zD_025.calc_quantities_of_interest_opt(data_path, 'data2022_06_13_16_42_59_16in_prop_400kv_22V_MN4014_T_motor_zD_025_optimal_fit_cmd.csv', '16.2 in, z/D = 0.25 opt');

%%
%Compare the experiment ceilnig with the results from the Bezier commands
p16in_prop_400kv.zD_025.plot_quant_vs_quant_plus_at_boundary_plus_equal_cmd(p16in_prop_400kv.zD_025.DataTable,'Total Thrust [g]', 'Total eEfficiency [g/W]');
hold on
% p16in_prop_400kv.zD_025.plot_quant_vs_quant(p16in_prop_400kv.zD_025.OptDataTable,'Total Thrust [g]', 'Total eEfficiency [g/W]');
plot(p16in_prop_400kv.zD_025.OptDataTable.('Total Thrust [g]'), p16in_prop_400kv.zD_025.OptDataTable.('Total eEfficiency [g/W]'), '-*');
legend('All','Boundary','Equal Commands','Bezier','Location','southoutside','Orientation','vertical','FontSize',12,'FontWeight','normal','FontName','Times','Interpreter','tex');


%%













