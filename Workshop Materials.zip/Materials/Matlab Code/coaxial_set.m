classdef coaxial_set
    %coaxial_set A class to define rotor set
    %   To put together all data and experiments related to one pair or
    %   motor and propeller
    
    properties
        Name
        KV
        PropellerPitch
        
        %The tests for each configuration
        zD_025 = coaxial_test
        
        nColors = {'black','red','#EDB120','blue','magenta','green'};
    end
    
    methods
        function obj = build(obj, name)
            obj.Name = name;
        end
   
    end
end



