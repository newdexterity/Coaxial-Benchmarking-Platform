function [upper_i] = get_upper_boundary(x,y,resolution)

%get the hard boundary
% b = boundary(x,y,1);
% x = x(b);
% y = y(b);
%find the upper boundary for y
max_x = max(x);
min_x = min(x);
diff = (max_x - min_x)/resolution;

% upper_x = zeros(resolution,1);
% upper_y = zeros(resolution,1);
upper_i = zeros(resolution,1);

for i=1:resolution+1
%     local_x_i = find(x > min_x+diff*(i-1) && x < min_x+diff*i);
%     min_x+diff*(i-1);
%     min_x+diff*i;
    local_x_i_larger = find(x >= (min_x+diff*(i-1)));
    local_x_i_smaller = find(x <= min_x+diff*i);
    local_x_i = intersect(local_x_i_larger,local_x_i_smaller);
    if(isempty(local_x_i))
        local_x_i = 100;
    end
    local_max_y = max(y(local_x_i));
    i;
    upper_i(i) = find(y == local_max_y);
%     upper_x(i) = x(upper_i);
%     upper_y(i) = y(upper_i);
end

end

