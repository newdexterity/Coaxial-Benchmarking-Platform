clear all

newcolors = {'black','red','#EDB120','blue','magenta','green'};

data_path = 'C:\Users\joaos\OneDrive\Documents\[PhD]\Project Omnidirectional Vehicle\Vanes\CASE Workshop 2022\Materials\Data\';

log_mine_2p5kg_zD0p25 = flight_log_analysis(data_path,'endurance_test_manual_my_alloc_2p5_kg_zD_0p25_log_159_2021-12-27-17-14-28.ulg','Proposed 2.5 kg z/D = 0.25','Mine');
log_reg_2p5kg_zD0p25 = flight_log_analysis(data_path,'endurance_test_manual_reg_alloc_2p5_kg_zD_0p25_log_161_2021-12-28-04-42-30.ulg','Standard 2.5 kg z/D = 0.25','Reg');

%%

newcolors = {'black','red','#EDB120','blue','magenta','green'};

%calculate the average power
log_mine_2p5kg_zD0p25_avg_pwr = mean(log_mine_2p5kg_zD0p25.Power(53:1484));
log_reg_2p5kg_zD0p25_avg_pwr = mean(log_reg_2p5kg_zD0p25.Power(53:1571));
%make them a vector to add on the plot
log_mine_2p5kg_zD0p25_avg_pwr_v = log_mine_2p5kg_zD0p25_avg_pwr + zeros(size(log_mine_2p5kg_zD0p25.Power));
log_reg_2p5kg_zD0p25_avg_pwr_v = log_reg_2p5kg_zD0p25_avg_pwr + zeros(size(log_reg_2p5kg_zD0p25.Power));

figure;
plot(log_mine_2p5kg_zD0p25.Time_battery, log_mine_2p5kg_zD0p25.Power,'-','Color',[0.5 0.5 0.5])
hold on
grid on
plot(log_reg_2p5kg_zD0p25.Time_battery, log_reg_2p5kg_zD0p25.Power,'-','Color','red')
plot(log_mine_2p5kg_zD0p25.Time_battery, log_mine_2p5kg_zD0p25_avg_pwr_v,'--','Color','black','LineWidth',1.5)
plot(log_reg_2p5kg_zD0p25.Time_battery, log_reg_2p5kg_zD0p25_avg_pwr_v,'--','Color','black','LineWidth',1.5)
ylabel('Power [W]','FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
xlabel('Time [min]','FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
title("z/D = 0.25",'FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
legend(log_mine_2p5kg_zD0p25.Name,log_reg_2p5kg_zD0p25.Name,'Location','northeastoutside','FontSize',14,'FontWeight','normal','FontName','Times');
colororder(newcolors)
ylim([750 950])


%%
%Verify commands
%Rotor set 1
figure('Position', [10 10 300 250]);
plot(log_mine_2p5kg_zD0p25.Time_actuator_outputs, log_mine_2p5kg_zD0p25.Actuator_outputs(:,1),'-')
hold on
plot(log_mine_2p5kg_zD0p25.Time_actuator_outputs, log_mine_2p5kg_zD0p25.Actuator_outputs(:,6),'-')
ylabel('PWM','FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
xlabel('Time','FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
title(log_mine_2p5kg_zD0p25.Name,'FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
legend('1','6','Location','northeastoutside','FontSize',14,'FontWeight','normal','FontName','Times');

figure('Position', [10 10 300 250]);
plot(log_reg_2p5kg_zD0p25.Time_actuator_outputs, log_reg_2p5kg_zD0p25.Actuator_outputs(:,1),'-')
hold on
plot(log_reg_2p5kg_zD0p25.Time_actuator_outputs, log_reg_2p5kg_zD0p25.Actuator_outputs(:,6),'-')
ylabel('PWM','FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
xlabel('Time','FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
title(log_reg_2p5kg_zD0p25.Name,'FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
legend('1','6','Location','northeastoutside','FontSize',14,'FontWeight','normal','FontName','Times');







