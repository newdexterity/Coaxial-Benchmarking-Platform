classdef flight_log_analysis
    %flight_log_analysis To obatain an analyze flight log data
    
    properties
        Allocation_type
        ulog
        Name
        msg
        current_filtered
        voltage_filtered
        Time_battery
        Power
        Actuator_outputs
        Time_actuator_outputs
        
        nColors = {'black','red','#EDB120','blue','magenta','green'};
    end
    
    methods
        function obj = flight_log_analysis(data_path, file, name, alloc_type)
            %Construct an instance of this class
            obj.Allocation_type = alloc_type;
            obj.Name = name;
            
            path = [data_path,file];
            %Load the ULOG file. Specify the relative path of the file.
            obj.ulog = ulogreader(path);   
%             obj.msg = readTopicMsgs(obj.ulog);
            battery_status = readTopicMsgs(obj.ulog,'TopicNames',{'battery_status'},'InstanceID',{0});
            obj.current_filtered = battery_status.TopicMessages{1,1}.current_filtered_a;
            obj.voltage_filtered = battery_status.TopicMessages{1,1}.voltage_filtered_v;
            obj.Time_battery = battery_status.TopicMessages{1,1}.timestamp;
            obj.Time_battery = duration(obj.Time_battery,'Format','mm:ss.S');
            obj.Time_battery = obj.Time_battery - obj.Time_battery(1);
            obj.Power = obj.current_filtered.*obj.voltage_filtered;
            
            actuator_outputs = readTopicMsgs(obj.ulog,'TopicNames',{'actuator_outputs'},'InstanceID',{0});
            obj.Actuator_outputs = actuator_outputs.TopicMessages{1,1}.output;
            obj.Time_actuator_outputs = actuator_outputs.TopicMessages{1,1}.timestamp;
            
            %C:\Users\joaos\Documents\[PhD]\Project Omnidirectional Vehicle\Vanes\ICRA-RAL Coaxial stand\Flight_logs\endurance_test_manual_reg_alloc_2p5_kg_log_120_2021-12-19-20-14-42.ulg
            
            
        end
        
        function plot_current_filtered(obj)
            %plots basic quantities
            x = readTopicMsgs(obj.ulog,'TopicNames',{x_name},'InstanceID',{0});
            y = readTopicMsgs(obj.ulog,'TopicNames',{y_name},'InstanceID',{0});
            figure('Position', [10 10 300 250]);
            plot(x, y,'-')
            ylabel(y_name,'FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
            xlabel(x_name,'FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
            title(obj.Name,'FontSize',14,'FontWeight','normal','FontName','Times','Color','k');
            colororder(obj.nColors)
        end
    end
end

